package com.mycompany.exam2025q2;
public class Exam2025Q2 {

    public static void main(String[] args) {
        //object for my GUI or JFrame class
        ProductSalesAppGUI productSales = new ProductSalesAppGUI();
    }
}
