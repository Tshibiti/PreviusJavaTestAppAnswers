/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exam2025q2;
//import all packages needed to create JFrame

import javax.swing.*;//swing components
import java.awt.*;//layouts
import java.awt.event.*;//use this when we start creating events or clickable buttons
import java.io.*;

public class ProductSalesAppGUI extends JFrame implements ActionListener {
    //Object for product sales class

    ProductSales product = new ProductSales();

//creating Jframe components
    //Creating Jbutton to save and load product data
    JButton load_btn = new JButton("Load Product Data");
    JButton save_btn = new JButton("Save Product Data");
    //creating a text area to display the product sales data
    JTextArea display_txta = new JTextArea();
    //creating a label (read only) to dispay number of years
    JLabel years_lbl = new JLabel("");

    //Q 2. 3 Craeting a menu components(JMenuBar, JMenu, JMenuItems)
    JMenuBar menubar = new JMenuBar();
    //creating Jmenu
    JMenu file_menu = new JMenu("File");
    JMenu edit_menu = new JMenu("Edit");
    //creating JMenuItems
    JMenuItem exit_item = new JMenuItem("Exit");
    JMenuItem load_item = new JMenuItem("Load Product Data");
    JMenuItem save_item = new JMenuItem("Save Product Data");
    JMenuItem clear_item = new JMenuItem("Clear");

    //constructor
    public ProductSalesAppGUI() {
        //setting up JFrame
        setTitle("Product Sales Application");
        setSize(350, 400);
        setVisible(true);//so that our is visible when we run it
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(4, 1));//we will change later

        //adding components to JFrame
        this.setJMenuBar(menubar);
        menubar.add(file_menu);
        menubar.add(edit_menu);

        file_menu.add(exit_item);
        edit_menu.add(this.load_item);
        edit_menu.add(this.save_item);
        edit_menu.add(this.clear_item);

        add(this.load_btn);
        add(this.save_btn);
        add(this.display_txta);
        add(this.years_lbl);

        //adding button to action listener
        exit_item.addActionListener(this);
        load_item.addActionListener(this);
        save_item.addActionListener(this);
        load_btn.addActionListener(this);
        clear_item.addActionListener(this);
        save_btn.addActionListener(this);

    }//end of constructor

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == exit_item) {
            System.exit(0);
        } //end exit button functionality
        else if (e.getSource() == clear_item) {
            this.display_txta.setText("");
        }  else if (e.getSource() == load_btn || e.getSource() == load_item) {
            //will store all sales data  from the array
            int[][] all_data = product.GetProductSales();
            //diplaying total on Text Area
            display_txta.setText("Total Sales : " + product.GetTotalSales()
                    + "\nAvarage Sales : " + product.GetAverageSales()
                    + "\nSales over limit : " + product.GetSalesOverLimit()
                    + "\nSales under limit : " + product.getSalesUnderLimit()
            );
            this.years_lbl.setText("Years Processed " + product.GetProductsProcessed());

        }//end of load button
        else if (e.getSource() == save_btn || e.getSource() == save_item ) {
            //FileWriter class to write to the file

            try {
                //Object of FileWriter Class
                FileWriter writer = new FileWriter("data.txt");
                //Writing to the file
                writer.write("DATA LOG "
                        + "\n****************************\n"
                        + display_txta.getText()
                        + "\n****************************"
                );
                writer.close();
                JOptionPane.showMessageDialog(null, "File Created successfully");
            }//end of try
            catch (IOException error) {
                JOptionPane.showMessageDialog(null, "Error trying to create a file");

            }
        }//end save product button
    }

}//end of class 
