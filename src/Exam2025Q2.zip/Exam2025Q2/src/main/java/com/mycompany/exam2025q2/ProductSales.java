/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exam2025q2;

  

    public class ProductSales implements IProductSales {

        //Array that contain product data
        int[][] productSalesData = {
            {300, 150, 700},//row 1 Sales for year 1
            {250, 200, 600}//row 2 sales for year

        };
        int limit = 500;

        //retrun all the elements in the arrays
        @Override
        public int[][] GetProductSales() {
            return productSalesData;
        }

        //return the total
        @Override
        public int GetTotalSales() {
            //variable to store total
            int total = 0;
            for (int i = 0; i < productSalesData.length; i++) {
                for (int j = 0; j < productSalesData[i].length; j++) {
                    total = total + productSalesData[i][j]; //total += productSalesData[i][j];
                }

            }//end of for loop
            return total;
        }//end of method gettotalsales

        //limit is 500
        //return number of element in an array that are above 500
        @Override
        public int GetSalesOverLimit() {
            int count = 0;
            for (int i = 0; i < productSalesData.length; i++) {
                for (int j = 0; j < productSalesData[i].length; j++) {
                    if (productSalesData[i][j] > limit) {
                        count++; //count = count + 1//increment by 1 if the data is above 500
                    }//end of if
                }

            }//end of for loop
            return count;
        }
        //limit is 500
        //return number of element in an array that are under 500

        @Override
        public int getSalesUnderLimit() {
            int count = 0;
            for (int i = 0; i < productSalesData.length; i++) {
                for (int j = 0; j < productSalesData[i].length; j++) {
                    if( productSalesData[i][j] < limit ){
                     count ++;
                    }
                }

            }//end of for loop
            return count;
        }//end of method
    
//return the number years processed
    @Override
    public int GetProductsProcessed() {
      return productSalesData.length;
    }

    @Override
    public double GetAverageSales() {
        //will return 6 
        //int count = productSalesData[0].length * productSalesData.length;
        return GetTotalSales() / 6;
    }

}
