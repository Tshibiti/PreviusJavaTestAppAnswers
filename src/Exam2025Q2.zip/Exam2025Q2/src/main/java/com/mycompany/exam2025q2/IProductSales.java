package com.mycompany.exam2025q2;
public interface IProductSales {
  int[][] GetProductSales();
  int GetTotalSales();
  int GetSalesOverLimit();
  int getSalesUnderLimit();
  int GetProductsProcessed();
  double GetAverageSales();
}
